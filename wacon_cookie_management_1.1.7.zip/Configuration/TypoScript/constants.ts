
plugin.tx_waconcookiemanagement_cookiefreigabe {
    view {
        # cat=plugin.tx_waconcookiemanagement_cookiefreigabe/file; type=string; label=Path to template root (FE)
        templateRootPath = EXT:wacon_cookie_management/Resources/Private/Templates/
        # cat=plugin.tx_waconcookiemanagement_cookiefreigabe/file; type=string; label=Path to template partials (FE)
        partialRootPath = EXT:wacon_cookie_management/Resources/Private/Partials/
        # cat=plugin.tx_waconcookiemanagement_cookiefreigabe/file; type=string; label=Path to template layouts (FE)
        layoutRootPath = EXT:wacon_cookie_management/Resources/Private/Layouts/
    }
 
}

plugin.tx_waconcookiemanagement_script {
    view {
        # cat=plugin.tx_waconcookiemanagement_script/file; type=string; label=Path to template root (FE)
        templateRootPath = EXT:wacon_cookie_management/Resources/Private/Templates/
        # cat=plugin.tx_waconcookiemanagement_script/file; type=string; label=Path to template partials (FE)
        partialRootPath = EXT:wacon_cookie_management/Resources/Private/Partials/
        # cat=plugin.tx_waconcookiemanagement_script/file; type=string; label=Path to template layouts (FE)
        layoutRootPath = EXT:wacon_cookie_management/Resources/Private/Layouts/
    }
   
}
